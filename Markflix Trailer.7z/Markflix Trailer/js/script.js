const c = (el)=>document.querySelector(el);
const cs = (el)=>document.querySelectorAll(el);

//listagem dos modelos
modeloJson.map((item, index)=>{
    let modeloItem = c('.models .modelo-item').cloneNode(true);

    modeloItem.setAttribute('data-key', index);

    modeloItem.querySelector('.modelo-item-img img').src = item.img;
    modeloItem.querySelector('.modelo-item-name').innerHTML = item.name;
    modeloItem.querySelector('.modelo-item-avaliacao').innerHTML = `Nota:  ${item.avaliacao.toFixed(2)}`;

    modeloItem.querySelector('a').addEventListener('click', (e) => {
        e.preventDefault();

        let key = e.target.closest('.modelo-item').getAttribute('data-key');
        modalQT = 1;

        c('.modeloBig img').src = modeloJson[key].img;
        c('.modeloInfo h1').innerHTML = modeloJson[key].name;
        c('.modeloInfo .modeloInfo-desc').innerHTML = modeloJson[key].description;
        c('.modeloInfo .modeloInfo-addButton a').href = modeloJson[key].link;
        c('.modeloInfo .modeloInfo-actualavaliacao').innerHTML = `Nota: ${modeloJson[key].avaliacao.toFixed(2)}`;
        c('.modeloInfo-size.selected').classList.remove('selected');

        cs('.modeloInfo-size').forEach((size, sizeIndex) => {
            if(sizeIndex == 0){
                size.classList.add('selected');
            }

            size.querySelector('span').innerHTML = modeloJson[key].sizes[sizeIndex];
        });

        c('.modeloWindowArea').style.opacity = 0;
        c('.modeloWindowArea').style.display = 'flex';
        
        setTimeout(() =>{
            c('.modeloWindowArea').style.opacity = 1;
        }, 5);
    });

    c('.modelo-area').append(modeloItem);
});

//eventos Modal
function closeModal(){
    c('.modeloWindowArea').style.opacity = 0;
    setTimeout(()=>{
        c('.modeloWindowArea').style.display = 'none';
    }, 5);
}

cs('.modeloInfo-cancelButton, .modeloInfo-cancelMobileButton').forEach((item)=>{
    item.addEventListener('click', closeModal);
});


//tamanhos
cs('.modeloInfo-size').forEach((size, sizeIndex)=>{
    //ao clicar em um item
    size.addEventListener('click', () =>{
        //desmarca tudo
        c('.modeloInfo-size.selected').classList.remove('selected');
        //add marcação
        size.classList.add('selected');
    });
});